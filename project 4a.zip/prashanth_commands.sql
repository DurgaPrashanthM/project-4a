create table Frozen_toys(Frozen_NO char(20) PRIMARY KEY,Frozen_Name varchar(100),No_Of_toys int);

create table Prod_company(Prod_NO int NOT NULL,Prod_Name varchar(100),Rate float);

create table staff(Emp_NO int,Shop_Name varchar(100),Salary int,City char(50));

create table Turn_Over(Frozen_NO char(20),Selling_Price int,Net_Amt bigint,FOREIGN KEY(Frozen_NO) REFERENCES Frozen_toys(Frozen_NO));

create table Marketing(OrdNO int,Toys_Sold int,City char(50),EmpNo int);