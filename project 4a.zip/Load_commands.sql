LOAD DATA LOCAL INFILE 'c:/Users/pras0/Downloads/prasanth/Frozen_toys.csv' INTO table Frozen_toys FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'c:/Users/pras0/Downloads/prasanth/Prod_company.csv' INTO table Prod_company FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'c:/Users/pras0/Downloads/prasanth/Staff.csv' INTO table Staff FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'c:/Users/pras0/Downloads/prasanth/Turn_Over.csv' INTO table Turn_over FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;

LOAD DATA LOCAL INFILE 'c:/Users/pras0/Downloads/prasanth/Marketing.csv' INTO table Marketing FIELDS TERMINATED BY ',' LINES TERMINATED BY '\r\n' IGNORE 1 LINES;